from telethon import events
from uniborg.util import admin_cmd


@borg.on(admin_cmd(pattern="lol"))
async def _(event):
    if event.fwd_from:
        return
    await event.edit("😂\n😂\n😂\n😂\n😂😂😂😂\n\n   😂😂😂\n 😂         😂\n😂           😂\n 😂         😂\n   😂😂😂\n\n😂\n😂\n😂\n😂\n😂😂😂😂")
